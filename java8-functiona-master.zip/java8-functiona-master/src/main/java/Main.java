import katas.*;
import static org.junit.Assert.*;

public class Main {
    public static void main(String[] args) {
        assertEquals(CobineVideoAndUrlsByBookMarkDemo.execute().size(), 4);
        System.out.println("CobineVideoAndUrlsByBookMarkDemo solved!");

        assertEquals(CollectMoviesDemo.execute().size(), 2);
        System.out.println("CollectMoviesDemo  solved!");

        assertEquals(CollectToListMoviesDemo.execute().size(), 4);
        System.out.println("CollectToListMoviesDemo  solved!");

        assertEquals(FlatMapMovieListDemo.execute().size(), 4);
        System.out.println("FlatMapMovieListDemo solved!");

        assertEquals(MapMoviesAttributesDemo.execute(), 5.0, 0.0);
        System.out.println("MapMoviesAttributesDemo solved!");

        assertEquals(MapToDoubleMoviesDemo.execute(), "B.jpg");
        System.out.println("MapToDoubleMoviesDemo solved!");

        assertEquals(MoviesFilterDemo.execute().size(), 4);
        System.out.println("MoviesFilterDemo solved!");

        assertEquals(MovieStreamDemo.execute().size(), 3);
        System.out.println("MovieStreamDemo solved!");

        assertEquals(MoviewFlatMapDemo.execute().size(), 4);
        System.out.println("MoviewFlatMapDemo solved!");

        assertEquals(MoviewFlatMapDemo.execute().size(), 2);
        System.out.println("MoviewFlatMapDemo solved!");

        assertEquals(ReduceLargestBoxartOperatorDemo.execute().size(), 2);
        System.out.println("ReduceLargestBoxartOperatorDemo solved!");

        System.out.println("ALL DONE, you're a functional programming NINJA!");
    }
}
