java8-functional Programming
======================
Some s for functional programming in Java 8 

Just read the instructions inthis repo and try to finish them. You can also use TDD if you want - there are dummy tests for all programs.


-----

*  1: simple projection using map
*  2: filter() and map()
*  3: using map() and flattening the array using flatMap()
*  4: a simple query using map(), filter() and flatMap()
*  5: simple example using reduce()
*  6: map() and reduce() combined
*  7: more advanced queryin
*  8: combining collections using zip()
*  9: Complex Query
*  10: Transforming a data structure
*  11: Transforming a more complex data structure
